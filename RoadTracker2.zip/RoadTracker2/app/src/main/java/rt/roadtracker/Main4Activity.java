package rt.roadtracker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.util.*;
import java.text.SimpleDateFormat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Main4Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        //build.gradlebuild.gradlebuild.gradle
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Road");
        //myRef.setValue("I love HackPSU");
        //myRef.push();
        //String val=myRef.child("Road Name").get


        Button button = (Button) findViewById(R.id.button4);
        button.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v){

                double hourStart = 1;
                double duration= 9;
                double minStart = 0;
                double minFraction = 0;
                double endTime;
                int y = 0;
                int totalMinsCurrent;
                boolean storm = true;
                String current = "";


                Calendar cal = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

                current = sdf.format(cal.getTime());
                totalMinsCurrent = toMins(current);

                System.out.println(totalMinsCurrent);

                // System.out.println( sdf.format(cal.getTime()) );


                endTime = hourStart + duration;
                minFraction = minStart/60.0;
                endTime += minFraction;
                System.out.println(endTime*60);



                System.out.println("updated to cleared");



                if( endTime < totalMinsCurrent)
                {
                    storm = false;
                    //   y++; //if statement thatresets conditon of roads will not execute if y = 1 (snow has stopped)
                }
                try {
                    Thread.sleep(3000);
                    throw new IllegalArgumentException();
                }
                catch(Exception e){
                    System.out.print("");
                }

                if(storm && y < 1)
                {
                    System.out.println("Roads Covered");
                }
            }
        });
    }

    public static int toMins(String s)
    {
        String[] hourMin = s.split(":");
        int hour = Integer.parseInt(hourMin[0]);
        int mins = Integer.parseInt(hourMin[1]);
        int hoursInMins = hour * 60;

        return hoursInMins + mins;
    }

}

